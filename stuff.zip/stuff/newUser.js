﻿const signupForm = document.querySelector('#NewUserInfo');
signupForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const email = signupForm['NewEmail'].value;
    const password = signupForm['NewPassword'].value;

    firebase.auth().createUserWithEmailAndPassword(email, password);
    console.log("User made with credentials: " + email + " & " + password);
})