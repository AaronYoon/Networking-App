﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your Javascript code.

function openForum() {
	document.getElementById("myForm").style.display = "block";
}
function closeForum() {
	document.getElementById("myForm").style.display = "none";
}

/*
$('#post').click(function() {
	$('#forumbox').append($('<li class="flex-item">').text('Hello'));
	$(this).insertAfter($('[class="flex-item"]').last());
}); 
*/

function openprofile() {

}

function postForum() {
	$('#forumbox').append($('<li class="flex-item">').text('Hello'));
	$(this).insertAfter($('[class="flex-item"]').last());
} 