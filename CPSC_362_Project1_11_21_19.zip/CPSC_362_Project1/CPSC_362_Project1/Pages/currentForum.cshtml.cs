using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Google.Cloud.Firestore;

namespace CPSC_362_Project1.Pages
{
    [BindProperties(SupportsGet = true)]
    public class currentForumModel : PageModel
    {
        [BindProperty]
        public string searchValue{ get; set; } 
        [BindProperty]
        public  Dictionary<object,object> username { get; set; }
        public async Task OnGetAsync()
        
        {
            
            if (searchValue != null)
            {
                FirestoreDb db = FirestoreDb.Create("networking-application");
                CollectionReference formRef = db.Collection(searchValue).Document("General").Collection("General Chat");
                Query queryMessage = formRef.WhereEqualTo("massage", true).WhereEqualTo("user", true);

                QuerySnapshot queryMessageSnapshot = await queryMessage.GetSnapshotAsync();
            }
            else
            {
                username = new Dictionary<object, object>();
                username.Add("test User1", "This messsage is the first test");
                username.Add("test User2", "This messsage is the second test");
            }

        }

        public async Task OnPostAsync()
        {
            if (searchValue != null)
            {
                FirestoreDb db = FirestoreDb.Create("networking-application");
                //CollectionReference formRef = db.Collection(searchValue).Document("General").Collection("General Chat");

                //CollectionReference formRef = db.Collection("Form Root").Document("Beer").Collection("Beer Master Collection").Document("Companies").Collection("Allagash").Document("General").Collection("General Chat");

                Query formQuery = db.Collection("Root").Document("Beer").Collection("Beer_Master_Collection").Document("Companies").Collection(searchValue).Document("General").Collection("General_Chat");


                //Query queryMessage = formRef.WhereEqualTo("message").WhereEqualTo("username", true);

                //Query queryMessage = formRef.WhereEqualTo("userName", "jDoe");

                QuerySnapshot queryMessageSnapshot = await formQuery.GetSnapshotAsync();

                username.Clear();

                foreach (DocumentSnapshot documentSnapshot in queryMessageSnapshot.Documents)
                {
                    //username = documentSnapshot.ToDictionary();
                    Dictionary<string, object> temp = documentSnapshot.ToDictionary();

                    object message = temp.FirstOrDefault(x => x.Key == "message").Value;

                    object userName = temp.FirstOrDefault(x => x.Key == "userName").Value;

                    username.Add(userName, message);
                }



                //DocumentSnapshot documentSnapshot = await queryMessageSnapshot.Documents;

                //username = queryMessageSnapshot.toDictionary();



            }
        }
    }
}