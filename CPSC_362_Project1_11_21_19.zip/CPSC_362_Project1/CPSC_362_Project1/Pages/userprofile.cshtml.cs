﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Google.Cloud.Firestore;


namespace CPSC361_ClassProject.Pages
{
    public class userprofileModel : PageModel
    {
        public object userLabel { get; set; }
        public object aboutUser { get; set; }
        public async Task OnGetAsync()
        {

            FirestoreDb db = FirestoreDb.Create("networking-application");
            Console.WriteLine("Created Cloud Firestore client with project ID: {0}", "networking-application");
            //System.Diagnostics.Debug.WriteLine("this happend0");

            //DocumentReference docRef = db.Collection("Test").Document("user2Test");
            //Dictionary<string, object> user = new Dictionary<string, object>
            //{
            //    { "First", "larry" },
            //    { "Last", "yesington" },
            //    { "DOB", "10/10/1812" }
            //};
            //await docRef.SetAsync(user);

            //CollectionReference usersRef = db.Collection("users");
            //QuerySnapshot snapshot = await usersRef.GetSnapshotAsync();
            //foreach (DocumentSnapshot document in snapshot.Documents)
            //{
            //    System.Diagnostics.Debug.WriteLine(document.Id);
            //    Dictionary<string, object> documentDictionary = document.ToDictionary();
            //    Console.WriteLine("First: {0}", documentDictionary["First"]);
            //    if (documentDictionary.ContainsKey("Middle"))
            //    {
            //        Console.WriteLine("Middle: {0}", documentDictionary["Middle"]);
            //    }
            //    Console.WriteLine("Last: {0}", documentDictionary["Last"]);
            //    Console.WriteLine("DOB: {0}", documentDictionary["Born"]);
            //    Console.WriteLine();
            //}

            

            DocumentReference userRef = db.Collection("Users").Document("user1");
            DocumentSnapshot snapshot = await userRef.GetSnapshotAsync();
            if (snapshot.Exists)
            {
                Dictionary<string, object> userInfo = snapshot.ToDictionary();

                //userLabel = userInfo.ElementAt(2).Value;

                userLabel = "User: " + userInfo.FirstOrDefault(x => x.Key == "userName").Value;
                aboutUser = userInfo.FirstOrDefault(x => x.Key == "userDescription").Value;
       
            }
            else
            {
                System.Diagnostics.Debug.WriteLine("Document {0} does not exist!", snapshot.Id);
            }
            



        }
    }
}