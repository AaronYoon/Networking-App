﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Google.Cloud.Firestore;

namespace CPSC361_ClassProject.Pages
{
    public class newUserModel : PageModel
    {
        public string newFirstName { set; get; }
        public string newLastName { set; get; }
        public string newAddress { set; get; }
        public string newCountry { set; get; }
        public void OnGet()
        {

        }

        public async void OnPost()
        {
            newFirstName = Request.Form["NewFirstName"];
            newLastName = Request.Form["NewLastName"];
            newAddress = Request.Form["NewAddress"];
            newCountry = Request.Form["NewCountry"];
            string newEmail = "test@123.org";


            System.Diagnostics.Debug.WriteLine("Here i am!");
            System.Diagnostics.Debug.WriteLine(newFirstName);
            System.Diagnostics.Debug.WriteLine(newCountry);

            FirestoreDb db = FirestoreDb.Create("networking-application");

            DocumentReference docRef = db.Collection("Users").Document(newEmail);

            Dictionary<string, object> userAdd = new Dictionary<string, object>
            {
                {"FirstName", newFirstName },
                {"LastName", newLastName},
                {"Country", newCountry}
            };

            await docRef.SetAsync(userAdd);


        }
    }
}