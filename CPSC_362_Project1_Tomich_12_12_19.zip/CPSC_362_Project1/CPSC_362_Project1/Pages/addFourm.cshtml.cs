using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Google.Cloud.Firestore;

namespace CPSC_362_Project1.Pages
{
   
    public class addFourmModel : PageModel
    {
        [BindProperty]
        public string mainTopic { get; set; }
        [BindProperty]
        public string subTopic { get; set; }
        [BindProperty]
        public string formName { get; set; }
        [BindProperty]
        public string firstMessage { get; set; }
        [BindProperty]
        public string userName { get; set; }
        public void OnGet()
        {
        }

        public async Task OnPostAsync()
        {
            FirestoreDb db = FirestoreDb.Create("networking-application");

            Console.WriteLine(mainTopic);
            //NOTE: If the document does not exist, it will be created. If the document does exist, its contents will be overwritten with the newly provided data, unless you specify that the data should be merged into the existing document, as follows:

            DocumentReference userRef = db.Collection("Form Root").Document(mainTopic).Collection(mainTopic + "Master Collection").Document(subTopic).Collection(subTopic + " General").Document(formName).Collection(formName + "Chat").Document(userName);

           
            


            //getting the current timestamp
            String timeStamp = DateTime.Now.ToString();

            Dictionary<string, string> update = new Dictionary<string, string>
            {
                {"dateOfMSG", timeStamp },
                {"message",  firstMessage},
                {"userName", userName}
            };

            await userRef.SetAsync(update);

        }
    }
}
