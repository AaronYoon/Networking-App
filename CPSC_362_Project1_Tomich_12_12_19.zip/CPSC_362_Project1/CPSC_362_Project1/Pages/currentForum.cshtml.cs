using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Google.Cloud.Firestore;

namespace CPSC_362_Project1.Pages
{
    [BindProperties(SupportsGet = true)]
    public class currentForumModel : PageModel
    {
        [BindProperty]
        public string searchValue{ get; set; } 
        [BindProperty]
        public  Dictionary<object,object> username { get; set; }
        [BindProperty]
        public int isValid { get; set; } = -1;
        [BindProperty]
        public string commentValue { get; set; }

        public async Task OnGetAsync()
        
        {
            
            if (searchValue != null)
            {
                isValid = 1;
                FirestoreDb db = FirestoreDb.Create("networking-application");
                CollectionReference formRef = db.Collection(searchValue).Document("General").Collection("General Chat");
                Query queryMessage = formRef.WhereEqualTo("massage", true).WhereEqualTo("user", true);

                QuerySnapshot queryMessageSnapshot = await queryMessage.GetSnapshotAsync();
            }
            else
            {
                username = new Dictionary<object, object>();
                username.Add("test User1", "This messsage is the first test");
                username.Add("test User2", "This messsage is the second test");
            }

        }

        public async Task OnPostAsync()
        {
            if (searchValue != null)
            {
                FirestoreDb db = FirestoreDb.Create("networking-application");
                username.Clear();

                //Query formQuery = db.Collection("Root").Document("Beer").Collection("Beer_Master_Collection").Document("Companies").Collection(searchValue).Document("General").Collection("General_Chat");

                CollectionReference searchRef = db.Collection("NewRoot");
                Query query = searchRef.WhereEqualTo("forumName", searchValue);
           
                QuerySnapshot queryMessageSnapshot = await query.GetSnapshotAsync();
                int test = queryMessageSnapshot.Count;
                if (queryMessageSnapshot.Count > 0)
                {
                    isValid = 1;
                    CollectionReference finalRef = db.Collection("ConversationRoot").Document(searchValue).Collection("ConversationCollection");
                    Query myQ = finalRef.OrderBy("dateOfMsg");
                    QuerySnapshot queryMessageSnapshotFinal = await myQ.GetSnapshotAsync();

                    foreach (DocumentSnapshot documentSnapshot in queryMessageSnapshotFinal.Documents)
                    {

                        //username = documentSnapshot.ToDictionary();
                        Dictionary<string, object> temp = documentSnapshot.ToDictionary();

                        object message = temp.FirstOrDefault(x => x.Key == "message").Value;

                        object userName = temp.FirstOrDefault(x => x.Key == "userName").Value;
                        userName += ": " + temp.FirstOrDefault(x => x.Key == "dateOfMsg").Value;

                        username.Add(userName, message);
                    }

                }
                else
                {
                    isValid = 0;
                    searchValue = "404: Did not find";
                    username.Add("ErrorData", "Search not Found");
                }
            }

            //In testing phase
            if (commentValue != null)
            {
                FirestoreDb db = FirestoreDb.Create("networking-application");
                CollectionReference finalRef = db.Collection("ConversationRoot").Document("homeBrewersGuide").Collection("ConversationCollection");
                //String timeStamp = DateTime.Now.ToString();
                //object timeStamp = DateTime.Now;
                var timeStamp = DateTime.SpecifyKind(DateTime.Now, DateTimeKind.Utc);
                DocumentReference docRef = finalRef.Document();

                Dictionary<string, object> comment = new Dictionary<string, object>
                        {
                            { "userName", "jsmith" },
                            { "message", commentValue},
                            { "dateOfMsg", timeStamp }
                        };

                await docRef.SetAsync(comment);
            }
        }
    }
}