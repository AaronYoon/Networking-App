from django.urls import path

from .views import ForumPageView, LoginPageView, UserPageView, PolicyPageView, PrivacyPageView, CookiesPageView, TermsPageView

from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('policy/', PolicyPageView.as_view(), name='policy'),
    path('terms/', TermsPageView.as_view(), name='terms'),
    path('cookies/', CookiesPageView.as_view(), name='cookies'),
    path('privacy/', PrivacyPageView.as_view(), name='privacy'),
    path('user/', UserPageView.as_view(), name='user'),
    path('forum/', ForumPageView.as_view(), name='home'),
    path('', LoginPageView.as_view(), name='login'),
    ] + static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
