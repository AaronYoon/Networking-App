from django.views.generic import TemplateView

class UserPageView(TemplateView):
    template_name = 'userprofile.html'

class LoginPageView(TemplateView):
    template_name = 'index.html'

class ForumPageView(TemplateView):
    template_name = 'forum.html'

class PolicyPageView(TemplateView):
    template_name = 'policy.html'

class TermsPageView(TemplateView):
    template_name = 'terms.html'

class CookiesPageView(TemplateView):
    template_name = 'cookies.html'

class PrivacyPageView(TemplateView):
    template_name = 'privacy.html'
