function messageUser()
{
  document.getElementById("myForm").style.display = "block";
}
function closeMessage()
{
  document.getElementById("myForm").style.display = "none";
}
