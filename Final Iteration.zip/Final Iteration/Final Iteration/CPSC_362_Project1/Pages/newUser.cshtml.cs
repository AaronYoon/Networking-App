﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Runtime.CompilerServices;
using Google.Cloud.Firestore;

namespace CPSC361_ClassProject.Pages
{
    public class newUserModel : PageModel
    {
        public object newFirstName { set; get; }
        public object newLastName { set; get; }
        public object newEmail { set; get; }
        public object newPassword { set; get; }

        public async Task OnPostAsync()
        {
            newFirstName = Request.Form["NewFirstName"];
            newLastName = Request.Form["NewLastName"];
            newEmail = Request.Form["NewEmail"];
            newPassword = Request.Form["NewPassword"];

            FirestoreDb db = FirestoreDb.Create("networking-application");

            DocumentReference docRef = db.Collection("Users").Document();

            Dictionary<string, object> userAdd = new Dictionary<string, object>
            {
                {"FirstName", newFirstName },
                {"LastName", newLastName},
                {"Email", newEmail },
                {"Password", newPassword }
            };

            await docRef.SetAsync(userAdd);
        }
    }
}