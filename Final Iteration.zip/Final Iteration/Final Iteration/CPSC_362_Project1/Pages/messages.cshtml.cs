﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Google.Cloud.Firestore;

namespace CPSC_362_Project1.Pages
{
    public class messagesModel : PageModel
    {
        public object otherUser { get; set; }
        public object subjectLine { get; set; }
        public List<string> chatIDs = new List<string>();
        public object IDnum { get; set; }
        public List<string> Messages = new List<string>();
        public object messageHolder { get; set; }
        public int numPosts{ get; set; }
        public List<string> subjects = new List<string>();
        public object subjectHolder { get; set; }
        public async Task OnGetAsync()
        {
            numPosts = 0;
            FirestoreDb db = FirestoreDb.Create("networking-application");

            Query chatsQuery = db.Collection("Users").Document("user1").Collection("Chats");
            QuerySnapshot chatsQuerySnapshot = await chatsQuery.GetSnapshotAsync();
            foreach (DocumentSnapshot documentSnapshot in chatsQuerySnapshot.Documents)
            {
                Dictionary<string, object> IDs = documentSnapshot.ToDictionary();
                
                IDnum = IDs.FirstOrDefault(x => x.Key == "ID").Value;
                chatIDs.Add(IDnum.ToString());

                subjectHolder = IDs.Last(z => z.Key == "subject").Value;
                subjects.Add(subjectHolder.ToString());



                Query messageQuery = db.Collection("Chats").Document(IDnum.ToString()).Collection("Messages");
                QuerySnapshot messageSnapshot = await messageQuery.GetSnapshotAsync();
                foreach(DocumentSnapshot docSnap2 in messageSnapshot.Documents)
                {
                    Dictionary<string, object> Text = docSnap2.ToDictionary();
                    foreach(KeyValuePair<string,object> set in Text)
                    {
                        messageHolder = Text.FirstOrDefault(y => y.Key == "text").Value;
                        Messages.Add(messageHolder.ToString());
                        numPosts++;
                    }
                }

                    
             
            }

            


        }
    }
}