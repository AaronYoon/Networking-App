﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Google.Cloud.Firestore;

namespace CPSC361_ClassProject.Pages
{
    public class forumModel : PageModel
    {
        public int numPosts { get; set; }

        public List<string> forumTitles = new List<string>();
        public List<string> forumTexts = new List<string>();
        public List<string> forumconnections = new List<string>();


        public async Task OnPostAsync()
        {
            FirestoreDb db = FirestoreDb.Create("networking-application");


            DocumentReference connectionRef = db.Collection("Users").Document("apple@test.com");
            DocumentSnapshot connectionsnapshot = await connectionRef.GetSnapshotAsync();
            if (connectionsnapshot.Exists)
            {
                Console.WriteLine("Document data for {0} document:", connectionsnapshot.Id);
                Dictionary<string, object> connections = connectionsnapshot.ToDictionary();
                foreach (KeyValuePair<string, object> pair in connections)
                {
                    Console.WriteLine("{0}: {1}", pair.Key, pair.Value);
                    forumconnections.Add(connections.FirstOrDefault().Value.ToString());
                }
            }
            else{
                Console.WriteLine("Document {0} does not exist!", connectionsnapshot.Id);
            }


            DocumentReference userRef = db.Collection("Post").Document("UserPosts");
            DocumentSnapshot snapshot = await userRef.GetSnapshotAsync();
            if (snapshot.Exists)
            {
                Dictionary<string, object> userInfo = snapshot.ToDictionary();

                int index = 0;
                while (userInfo.ContainsKey("title" + index))
                {
                    forumTitles.Add(userInfo.FirstOrDefault(x => x.Key == "title" + index).Value.ToString());
                    forumTexts.Add(userInfo.FirstOrDefault(x => x.Key == "forumtext" + index).Value.ToString());
                    numPosts = index + 1;
                    index++;
                }
            }
            else
            {
                System.Diagnostics.Debug.WriteLine("Document {0} does not exist!", snapshot.Id);
            }
        }
    }
}