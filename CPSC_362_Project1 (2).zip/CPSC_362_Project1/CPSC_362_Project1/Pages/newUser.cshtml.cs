﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace CPSC361_ClassProject.Pages
{
    public class newUserModel : PageModel
    {
        public string newFirstName { set; get; }
        public string newLastName { set; get; }
        public string newAddress { set; get; }
        public void OnGet()
        {

        }

        public void OnPost()
        {
            newFirstName = Request.Form["NewFirstName"];
            newLastName = Request.Form["NewLastName"];
            newAddress = Request.Form["NewAddress"];

            System.Diagnostics.Debug.WriteLine(newFirstName);

        }
    }
}